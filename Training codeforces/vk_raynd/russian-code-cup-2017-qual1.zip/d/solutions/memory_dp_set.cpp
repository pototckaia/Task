#include <bits/stdc++.h>

int main() {
  int tests;
  scanf("%d", &tests);
  while (tests--) {
    int n, k, q;
    scanf("%d%d%d", &n, &k, &q);
    std::vector<int> s(q + 1, 0);
    for (int i = 0; i < q; i++) {
      scanf("%d", &s[i]);
    }
    std::vector<std::vector<int>> queries(q);
    for (int i = 0; i < q; i++) {
      int c;
      scanf("%d", &c);
      for (int j = 0; j < c; j++) {
        int x;
        scanf("%d", &x);
        queries[i].push_back(x);
      }
    }
    int j = q - 1;
    int different = 0;
    std::vector<int> cnt(n + 1, 0);
    std::vector<int> go(q, -1);
    std::vector<bool> added(q, false);
    for (int i = q - 1; i >= 0; i--) {
      while (j >= 0) {
        if (!added[j]) {
          for (int x : queries[j]) {
            if (++cnt[x] == 1) {
              different++;
            }
          }
          added[j] = true;
        }
        if (different > k) {
          break;
        }
        j--;
      }
      if (j < 0) {
        break;
      }
      go[i] = j;
      for (int x : queries[i]) {
        if (--cnt[x] == 0) {
          different--;
        }
      }
    }
    std::vector<long long> dp(q, LLONG_MAX);
    std::set<std::pair<long long, int>> costs;
    costs.emplace(s[1], 0);
    int p = 0;
    dp[0] = 0;
    for (int i = 1; i < q; i++) {
      for (int j = p; j < go[i]; j++) {
        costs.erase({dp[j] + s[j + 1], j});
      }
      if (go[i] < 0) {
        dp[i] = 0;
        costs.emplace(s[i + 1], i);
        continue;
      }
      p = go[i];
      dp[i] = costs.begin()->first;
      costs.emplace(dp[i] + s[i + 1], i);
    }
    printf("%lld\n", dp[q - 1]);
  }
  return 0;
}
