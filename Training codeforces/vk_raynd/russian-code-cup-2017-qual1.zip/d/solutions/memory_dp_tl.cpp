#include <bits/stdc++.h>

int main() {
  int tests;
  scanf("%d", &tests);
  while (tests--) {
    int n, k, q;
    scanf("%d%d%d", &n, &k, &q);
    std::vector<int> s(q);
    for (int i = 0; i < q; i++) {
      scanf("%d", &s[i]);
    }
    std::vector<std::vector<int>> queries(q);
    for (int i = 0; i < q; i++) {
      int c;
      scanf("%d", &c);
      for (int j = 0; j < c; j++) {
        int x;
        scanf("%d", &x);
        queries[i].push_back(x);
      }
    }
    std::vector<int> go(q, -1);
    for (int i = q - 1; i >= 0; i--) {
      int different = 0;
      std::map<int, int> cnt;
      int j = i;
      while (j >= 0) {
        for (int x : queries[j]) {
          if (++cnt[x] == 1) {
            different++;
          }
        }
        if (different > k) {
          break;
        }
        j--;
      }
      go[i] = j;
    }
    
    std::vector<long long> dp(q, LLONG_MAX);
    dp[0] = 0;
    for (int i = 1; i < q; i++) {
      if (go[i] < 0) {
        dp[i] = 0;
        continue;
      }
      for (int j = go[i]; j < i; j++) {
        dp[i] = std::min(dp[i], dp[j] + s[j + 1]);
      }
    }
    printf("%lld\n", dp[q - 1]);
  }
  return 0;
}
