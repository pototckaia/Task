#include <bits/stdc++.h>

struct QueueMin {
  std::vector<int> left;
  std::vector<int> leftMin;
  std::vector<int> right;
  std::vector<int> rightMin;

  QueueMin() {}

  void push(int x) {
    left.push_back(x);
    int last = leftMin.empty() ? INT_MAX : leftMin.back();
    leftMin.push_back(std::min(last, x));
  }

  int pop() {
    if (right.empty()) {
      int last = INT_MAX;
      while (!left.empty()) {
        int x = left.back();
        left.pop_back();
        leftMin.pop_back();
        right.push_back(x);
        int new_last = std::min(last, x);
        rightMin.push_back(new_last);
        last = new_last;
      }
    }
    int result = right.back();
    right.pop_back();
    rightMin.pop_back();
    return result;
  }

  int min() {
    int lmin = leftMin.empty() ? INT_MAX : leftMin.back();
    int rmin = rightMin.empty() ? INT_MAX : rightMin.back();
    return std::min(lmin, rmin);
  }
};

int main() {
  int tests;
  scanf("%d", &tests);
  while (tests--) {
    int n, k, q;
    scanf("%d%d%d", &n, &k, &q);
    std::vector<int> s(q + 1, 0);
    for (int i = 0; i < q; i++) {
      scanf("%d", &s[i]);
    }
    std::vector<std::vector<int>> queries(q);
    for (int i = 0; i < q; i++) {
      int c;
      scanf("%d", &c);
      for (int j = 0; j < c; j++) {
        int x;
        scanf("%d", &x);
        queries[i].push_back(x);
      }
    }
    int j = q - 1;
    int different = 0;
    std::vector<int> cnt(n + 1, 0);
    std::vector<int> go(q, -1);
    std::vector<bool> added(q, false);
    for (int i = q - 1; i >= 0; i--) {
      while (j >= 0) {
        if (!added[j]) {
          for (int x : queries[j]) {
            if (++cnt[x] == 1) {
              different++;
            }
          }
          added[j] = true;
        }
        if (different > k) {
          break;
        }
        j--;
      }
      if (j < 0) {
        break;
      }
      go[i] = j;
      for (int x : queries[i]) {
        if (--cnt[x] == 0) {
          different--;
        }
      }
    }
    
    std::vector<int> dp(q, INT_MAX);
    QueueMin costs = QueueMin();
    costs.push(s[1]);
    int p = 0;
    dp[0] = 0;
    for (int i = 1; i < q; i++) {
      for (int j = p; j < go[i]; j++) {
        costs.pop();
      }
      if (go[i] < 0) {
        dp[i] = 0;
        costs.push(s[i + 1]);
        continue;
      }
      p = go[i];
      dp[i] = costs.min();
      costs.push(dp[i] + s[i + 1]);
    }
    printf("%d\n", dp[q - 1]);
  }
  return 0;
}
