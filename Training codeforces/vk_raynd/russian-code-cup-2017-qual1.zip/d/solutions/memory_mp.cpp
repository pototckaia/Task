#include <bits/stdc++.h>

#ifndef LOCAL
#define cerr dolor_sit_amet
#endif

#define mp make_pair
#define sz(x) ((int)((x).size()))
#define X first
#define Y second

using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
typedef pair < int , int > ipair;
typedef pair < ll , ll > lpair;
const int IINF = 0x3f3f3f3f;
const ll LINF = 0x3f3f3f3f3f3f3f3fll;
const double DINF = numeric_limits<double>::infinity();
const ll MOD = 1000000007;
const double EPS = 1e-9;
const int DX[] = { 1,  0, -1,  0,  1, -1,  1, -1};
const int DY[] = { 0,  1,  0, -1,  1, -1, -1,  1};
ll gcd(ll a, ll b) { return b ? gcd(b, a % b) : a; }
ll sqr(ll x) { return x*x; } ll sqr(int x) { return (ll)x*x; }
double sqr(double x) { return x*x; } ld sqr(ld x) { return x*x; }

// ========================================================================= //

const int N = 1 << 20;

class SegTree
{
	long long t[N * 2 - 1];
public:
	void set(int p, long long v)
	{
		t[p += N - 1] = v;
		while (p)
		{
			(--p) /= 2;
			t[p] = min(t[p*2 + 1], t[p*2 + 2]);
		}
	}

	long long getMin(int l, int r, int c = 0, int cl = 0, int cr = N - 1)
	{
		if (cl > r || cr < l)
			return LINF;
		if (l <= cl && cr <= r)
			return t[c];
		return min(getMin(l, r, c*2+1, cl, (cl+cr)/2), getMin(l, r, c*2+2, (cl+cr)/2+1, cr));
	}
} st;

void solve()
{
	int n, k, q;
	static int cost[N];
	static vector < int > v[N];
	scanf("%d%d%d", &n, &k, &q);
	for (int i = 0; i < q; ++i)
		scanf("%d", &cost[i]);
	cost[0] = 0;
	for (int i = 0; i < q; ++i)
	{
		int c;
		scanf("%d", &c);
		v[i] = vector<int>(c);
		for (int j = 0; j < c; ++j)
		{
			scanf("%d", &v[i][j]);
			--v[i][j];
		}
	}
	
	static int cnt[N];
	int acnt = 0;
	static int mlen[N];
	memset(cnt, 0, sizeof(int) * n);
	mlen[0] = 0;
	for (int i = 0; i < q; ++i)
	{
		while (i + mlen[i] < q)
		{
			for (int x : v[i + mlen[i]])
				if (!cnt[x]++)
					acnt++;
			if (acnt > k)
			{
				for (int x : v[i + mlen[i]])
					if (!--cnt[x])
						acnt--;
				break;
			}
			++mlen[i];
		}
		mlen[i + 1] = mlen[i] - 1;
		for (int x : v[i])
			if (!--cnt[x])
				acnt--;
	}
	st.set(q, 0);
	for (int i = q - 1; i >= 0; --i)
		st.set(i, cost[i] + st.getMin(i + 1, i + mlen[i]));
	cout << st.getMin(0, 0) << "\n";
}

int main()
{
    ios::sync_with_stdio(false);
	int t;
	scanf("%d", &t);
	while (t--)
		solve();

    return 0;
}
