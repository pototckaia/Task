#include <bits\stdc++.h>
using namespace std;


int calc(const vector<vector<int>> &a, int n, int m)
{
    int max_width = 0;
    for (int i = 0; i < n; i++)
    {
        int cnt = 0;
        for (int j = 0; j < m; j++)
        {
            if (a[i][j] == 1)
                cnt++;
            else
            {
                //cerr << cnt << ' ';
                max_width = max(cnt, max_width);
                cnt = 0;
            }           
        }
        //cerr << cnt << endl;
        max_width = max(cnt, max_width);
    }
    return max_width;
}

int main()
{
    int t;
    cin >> t;
    while (t--) 
    {
        int n, m, k;
        cin >> n >> m >> k;
        vector<vector<int>> a(n, vector<int>(m));
        vector<vector<int>> b(m, vector<int>(n));
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
            {
                cin >> a[i][j];
                b[j][i] = a[i][j];
            }
        int w = calc(a, n, m);
        int h = calc(b, m, n);
        //cout << w << ' ' << h << endl;
        int q = max(w, h);
        if (q > k)
            cout << "NO" << endl;
        else
        {
            cout << "YES" << endl;
            for (int i = 0; i < n; i++)
            {    
                for (int j = 0; j < m; j++)
                    if (a[i][j] == 0)
                        cout << 0 << ' ';
                    else
                        cout << (i + j) % q + 1 << ' ';
                cout << endl;
            }

        }
    }
    return 0;
}