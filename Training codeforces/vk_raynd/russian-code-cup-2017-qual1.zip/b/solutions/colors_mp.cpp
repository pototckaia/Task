#include <bits/stdc++.h>

#ifndef LOCAL
#define cerr dolor_sit_amet
#endif

#define mp make_pair
#define sz(x) ((int)((x).size()))
#define X first
#define Y second

using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
typedef pair < int , int > ipair;
typedef pair < ll , ll > lpair;
const int IINF = 0x3f3f3f3f;
const ll LINF = 0x3f3f3f3f3f3f3f3fll;
const double DINF = numeric_limits<double>::infinity();
const ll MOD = 1000000007;
const double EPS = 1e-9;
const int DX[] = { 1,  0, -1,  0,  1, -1,  1, -1};
const int DY[] = { 0,  1,  0, -1,  1, -1, -1,  1};
ll gcd(ll a, ll b) { return b ? gcd(b, a % b) : a; }
ll sqr(ll x) { return x*x; } ll sqr(int x) { return (ll)x*x; }
double sqr(double x) { return x*x; } ld sqr(ld x) { return x*x; }

// ========================================================================= //

const int N = 111;

int a[N][N];

void solve()
{
	int n, m, k;
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 0; i < n; ++i)
		for (int j = 0; j < m; ++j)
			scanf("%d", &a[i][j]);
	
	for (int i = 0; i < n; ++i)
	{
		int p = -1;
		for (int j = 0; j <= m; ++j)
			if (j == m || !a[i][j])
			{
				if (j - p - 1 > k)
				{
					cout << "NO\n";
					return;
				}
				p = j;
			}
	}
	for (int i = 0; i < m; ++i)
	{
		int p = -1;
		for (int j = 0; j <= n; ++j)
			if (j == n || !a[j][i])
			{
				if (j - p - 1 > k)
				{
					cout << "NO\n";
					return;
				}
				p = j;
			}
	}
	
	cout << "YES\n";
	for (int i = 0; i < n; ++i)
		for (int j = 0; j < m; ++j)
			cout << (a[i][j] ? (i + j) % k + 1 : 0) << " \n"[j == m - 1];
}

int main()
{
    ios::sync_with_stdio(false);

	int t;
	scanf("%d", &t);
	while (t--)
		solve();

    return 0;
}
