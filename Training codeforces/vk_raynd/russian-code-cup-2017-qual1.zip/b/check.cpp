#include "testlib.h"
#include <vector>
#include <iostream>

using namespace std;


template<typename T>
string to_string(const T& x) 
{
    stringstream ss;
    ss << x;
    return ss.str();
}

string check_colors(int n, int m, int k, vector<vector<int>> &a, bool trans)
{
    map<int, bool> was;
    for (int i = 0; i < n; i++)
    {
        was.clear();
        for (int j = 0; j < m; j++)
        {
            if (a[i][j] == 0)
            {
                was.clear();
            }
            else
            {
                if (was[a[i][j]])
                {   
                    if (!trans)
                        return "Horizontaly duplicate color in ans[" + to_string(i + 1) + "][" + to_string(j + 1) + "]";
                    return "Verticaly duplicate color in ans[" + to_string(j + 1) + "][" + to_string(i + 1) + "]";
                }
                was[a[i][j]] = true; 
            } 
        }
    }
    return "ok";
}


template<typename T>
string check(T &ouf, int n, int m, int k, vector<vector<int>> &a) 
{
    vector<vector<int>> c(m, vector<int>(n));
    vector<vector<int>> b(n, vector<int>(m));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
        {
            b[i][j] = ouf.readInt();
            c[j][i] = b[i][j];
            if (b[i][j] < 0 || b[i][j] > k)
                return "Incorrect ans[" + to_string(i + 1) + "][" + to_string(j + 1) + "] = " + to_string(b[i][j]);
            if (b[i][j] == 0 && a[i][j] != 0)
                return "ans[" + to_string(i + 1) + "][" + to_string(j + 1) + "] = 0, but in input was %d" + to_string(a[i][j]);
            if (b[i][j] != 0 && a[i][j] == 0)
                return "ans[" + to_string(i + 1) + "][" + to_string(j + 1) + "] = %d, but in input was 0" + to_string(b[i][j]);
        }
    string c1 = check_colors(n, m, k, b, false);
    string c2 = check_colors(m, n, k, c, true);    
    if (c1 != "ok")
        return c1;
    if (c2 != "ok")
        return c2;
    return "ok";
}
int main(int argc, char* argv[])
{
    registerTestlibCmd(argc, argv);
    
    
    int t = inf.readInt();
    int cnt = 0;
    while (cnt < t)
    {
        cnt++;
        int n = inf.readInt();
        int m = inf.readInt();
        int k = inf.readInt();
        vector<vector<int>> a(n, vector<int>(m));
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                a[i][j] = inf.readInt();
        
        string cans = ouf.readToken();
        string jans = ans.readToken();
        quitif(cans != "YES" && cans != "NO", _wa, "In %d test YES or NO expected %s find:", cnt, cans.c_str());
        quitif(jans != "YES" && jans != "NO", _fail, "In %d test YES or NO expected %s find: ", cnt, jans.c_str());
        
        string ccheck = "no";
        if (cans == "YES")
            ccheck = check(ouf, n, m, k, a);
        quitif(ccheck != "ok" && ccheck != "no", _wa, "In %d test %s" , cnt, ccheck.c_str());
        
        string jcheck = "no";
        if (jans == "YES")
            jcheck = check(ans, n, m, k, a);
        quitif(jcheck != "ok" && jcheck != "no", _fail, "In %d test %s" , cnt, jcheck.c_str());
        
        quitif(ccheck == "ok" && jcheck == "no", _fail, "In %d test contestant find answer, but jury doesn't", cnt);
        quitif(jcheck == "ok" && ccheck == "no", _wa, "In %d test jury find answer, but contestant doesn't", cnt);            
    }
    quitf(_ok, "%d tests", t);
    return 0;
}