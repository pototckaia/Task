n = int(input())
for _ in range(n):
	k, a, b = map(int, input().split())
	a, b = max(a, b), min(a, b)
	if b <= k - 2:
		print(k - a)
	else:
		print(b + 2 - a)
