import java.util.*;
import java.io.*;

public class concat_hard_av {

	final int MAX_SUM = 100_000;
	final int BLOCK_SIZE = 300;

	void solve() {
		int n = in.nextInt(), q = in.nextInt();
		String[] words = new String[n];
		Query[] queries = new Query[q];
		for (int i = 0; i < n; i++) {
			words[i] = in.nextToken();
		}
		for (int i = 0; i < q; i++) {
			queries[i] = new Query(in.nextInt() - 1, in.nextInt(), i);
		}
		int[] blockId = new int[n];
		int lastBlockSize = 0, lastBlock = 0;
		for (int i = 0; i < n; i++) {
			blockId[i] = lastBlock;
			lastBlockSize += words[i].length();
			if (lastBlockSize >= BLOCK_SIZE) {
				lastBlockSize = 0;
				lastBlock++;
			}
		}
		Arrays.sort(queries, new Comparator<Query>() {
			@Override
			public int compare(Query o1, Query o2) {
				if (blockId[o1.left] != blockId[o2.left]) {
					return o1.left - o2.left;
				}
				return o1.right - o2.right;
			}
		});
		
		long[] result = new long[q];
		TrieUnion ds = new TrieUnion(words);
		int curL = 0, curR = 0;
		for (Query query : queries) {
			while (curR < query.right) {
				ds.addWord(curR++);
			}
			while (curL > query.left) {
				ds.addWord(--curL);
			}
			while (curL < query.left) {
				ds.removeWord(curL++);
			}
			while (curR > query.right) {
				ds.removeWord(--curR);
			}
			result[query.id] = ds.getResult();
		}
		for (long r : result) {
			out.println(r);
		}
	}

	class TrieUnion {
		final int ALPH = 26;

		class Trie {
			int[][] next;
			int[] usedCounter;
			int[] letterFreqs;

			int states = 1;
			int activeStates = 0;

			public Trie() {
				next = new int[ALPH][MAX_SUM + 1];
				usedCounter = new int[MAX_SUM + 1];
				letterFreqs = new int[ALPH];
				for (int[] i : next) {
					Arrays.fill(i, -1);
				}
			}

			void insertWord(String s) {
				int cur = 0;
				for (int i = 0; i < s.length(); i++) {
					int c = s.charAt(i) - 'a';
					if (next[c][cur] == -1) {
						next[c][cur] = states++;
					}
					cur = next[c][cur];
				}
			}

			void activate(String s) {
				int cur = 0;
				for (int i = 0; i < s.length(); i++) {
					int c = s.charAt(i) - 'a';
					cur = next[c][cur];
					if (usedCounter[cur] == 0) {
						activeStates++;
						if (i > 0) {
							letterFreqs[c]++;
						}
					}
					usedCounter[cur]++;
				}
			}

			void deactivate(String s) {
				int cur = 0;
				for (int i = 0; i < s.length(); i++) {
					int c = s.charAt(i) - 'a';
					cur = next[c][cur];
					usedCounter[cur]--;
					if (usedCounter[cur] == 0) {
						activeStates--;
						if (i > 0) {
							letterFreqs[c]--;
						}
					}

				}
			}
		}

		String[] words, revWords;
		Trie prefixTrie, suffixTrie;
		long curResult = 0;

		public TrieUnion(String[] s) {
			this.words = s;
			this.revWords = new String[words.length];
			for (int i = 0; i < words.length; i++) {
				revWords[i] = new StringBuilder(words[i]).reverse().toString();
			}
			prefixTrie = new Trie();
			suffixTrie = new Trie();
			for (int i = 0; i < words.length; i++) {
				prefixTrie.insertWord(words[i]);
				suffixTrie.insertWord(revWords[i]);
			}
		}

		public void addWord(int i) {
			prefixTrie.activate(words[i]);
			suffixTrie.activate(revWords[i]);
		}

		public void removeWord(int i) {
			prefixTrie.deactivate(words[i]);
			suffixTrie.deactivate(revWords[i]);
		}

		public long getResult() {
			long result = 1L * prefixTrie.activeStates * suffixTrie.activeStates;
			for (int i = 0; i < ALPH; i++) {
				result -= 1L * prefixTrie.letterFreqs[i] * suffixTrie.letterFreqs[i];
			}
			return result;
		}

	}

	class Query {
		int left, right, id;

		public Query(int left, int right, int id) {
			super();
			this.left = left;
			this.right = right;
			this.id = id;
		}
	}

	FastScanner in;
	PrintWriter out;

	void run() {
		in = new FastScanner();
		out = new PrintWriter(System.out);
		solve();
		out.close();
	}

	class FastScanner {
		BufferedReader br;
		StringTokenizer st;

		public FastScanner() {
			br = new BufferedReader(new InputStreamReader(System.in));
		}

		public FastScanner(String s) {
			try {
				br = new BufferedReader(new FileReader(s));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		public String nextToken() {
			while (st == null || !st.hasMoreTokens()) {
				try {
					st = new StringTokenizer(br.readLine());
				} catch (IOException e) {
				}
			}
			return st.nextToken();
		}

		public int nextInt() {
			return Integer.parseInt(nextToken());
		}

		public long nextLong() {
			return Long.parseLong(nextToken());
		}

		public double nextDouble() {
			return Double.parseDouble(nextToken());
		}
	}

	public static void main(String[] args) {
		new concat_hard_av().run();
	}
}
