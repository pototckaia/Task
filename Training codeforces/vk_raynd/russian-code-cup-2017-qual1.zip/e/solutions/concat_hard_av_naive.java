import java.util.*;
import java.io.*;

public class concat_hard_av_naive {

	void solve() {
		int n = in.nextInt(), q = in.nextInt();
		String[] words = new String[n];
		for (int i = 0; i < n; i++) {
			words[i] = in.nextToken();
		}
		for (int Q = 0; Q < q; Q++) {
			int left = in.nextInt() - 1, right = in.nextInt() - 1;
			Set<String> result = new HashSet<>();
			for (int i = left; i <= right; i++) {
				for (int j = left; j <= right; j++) {
					for (int p = 1; p <= words[i].length(); p++) {
						for (int s = 0; s < words[j].length(); s++) {
							result.add(words[i].substring(0, p) + words[j].substring(s));
						}
					}
				}
			}
			out.println(result.size());
		}

	}

	FastScanner in;
	PrintWriter out;

	void run() {
		in = new FastScanner();
		out = new PrintWriter(System.out);
		solve();
		out.close();
	}

	class FastScanner {
		BufferedReader br;
		StringTokenizer st;

		public FastScanner() {
			br = new BufferedReader(new InputStreamReader(System.in));
		}

		public FastScanner(String s) {
			try {
				br = new BufferedReader(new FileReader(s));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		public String nextToken() {
			while (st == null || !st.hasMoreTokens()) {
				try {
					st = new StringTokenizer(br.readLine());
				} catch (IOException e) {
				}
			}
			return st.nextToken();
		}

		public int nextInt() {
			return Integer.parseInt(nextToken());
		}

		public long nextLong() {
			return Long.parseLong(nextToken());
		}

		public double nextDouble() {
			return Double.parseDouble(nextToken());
		}
	}

	public static void main(String[] args) {
		new concat_hard_av_naive().run();
	}
}
