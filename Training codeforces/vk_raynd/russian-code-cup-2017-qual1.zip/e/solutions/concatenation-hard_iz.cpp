#include <unordered_map>
#include <unordered_set>
#include <functional>
#include <sstream>
#include <vector>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <string>
#include <cassert>
#include <ctime>
#include <map>
#include <math.h>
#include <cstdio>
#include <set>
#include <deque>
#include <memory.h>
#include <queue>

#pragma comment(linker, "/STACK:64000000")
typedef long long ll;

using namespace std;

const int MAXK = 17;
const int MAXN = 1 << MAXK;
const int MOD = 0; // 1000 * 1000 * 1000 + 7;
const int SIGMA = 26;

int n, q;
string a[MAXN];
char buf[MAXN];
int l[MAXN], r[MAXN];
vector<int> qq[MAXN];
ll ans[MAXN];

struct fenwick {
	int f[MAXN];
	fenwick() {
		memset(f, 0, sizeof(f));
	}
	void add(int x, int y) {
		for (; x < MAXN; x |= x + 1) f[x] += y;
	}
	int get(int x) {
		int res = 0;
		for (; x >= 0; x = (x & (x + 1)) - 1) res += f[x];
		return res;
	}
	int get(int l, int r) {
		return get(r) - get(l - 1);
	}
};

struct node {
	int nxt[SIGMA];
	int last;

	node() {
		memset(nxt, -1, sizeof(nxt));
		last = 0;
	}
};

struct trie {
	node t[MAXN];
	int sz;
	fenwick f;
	vector<fenwick> letters;

	trie() {
		t[0] = node();
		sz = 1;
		letters.resize(SIGMA);
	}

	void add(string s, int tmr) {
		int cur = 0;
		vector<int> cnt(SIGMA);
		for (int i = 0; i < (int)s.length(); i++) {
			int c = s[i] - 'a';
			bool nw = 0;
			if (t[cur].nxt[c] == -1) {
				nw = 1;
				t[cur].nxt[c] = sz;
				t[sz] = node();
				sz++;
			}
			cur = t[cur].nxt[c];
			if (!nw) {
				f.add(t[cur].last, -1);
				if (i > 0) letters[c].add(t[cur].last, -1);
			}
			t[cur].last = tmr;
			f.add(t[cur].last, 1);
			if (i > 0) letters[c].add(t[cur].last, +1);
		}
	}
};

int main() {
	scanf("%d%d", &n, &q);
	for (int i = 0; i < n; i++) {
		scanf("%s", buf);
		a[i] = buf;
	}
	for (int i = 0; i < q; i++) {
		scanf("%d%d", &l[i], &r[i]);
		l[i]--; r[i]--;
		qq[r[i]].push_back(i);
	}

	trie t1 = trie(), t2 = trie();
	for (int i = 0; i < n; i++) {
		t1.add(a[i], i + 1);
		reverse(a[i].begin(), a[i].end());
		t2.add(a[i], i + 1);

		for (int id : qq[i]) {
			ans[id] = 1LL * t1.f.get(l[id] + 1, r[id] + 1) * t2.f.get(l[id] + 1, r[id] + 1);
			for (int j = 0; j < SIGMA; j++) {
				ans[id] -= 1LL * t1.letters[j].get(l[id] + 1, r[id] + 1) * t2.letters[j].get(l[id] + 1, r[id] + 1);
			}
		}
	}
	for (int i = 0; i < q; i++) {
		printf("%lld\n", ans[i]);
	}
	return 0;
}