#define _ijps 0
#define _CRT_SECURE_NO_DEPRECATE
#pragma comment(linker, "/STACK:667772160")
#include <iostream>
#include <cmath>
#include <vector>
#include <time.h>
#include <map>
#include <set>
#include <deque>
#include <cstdio>
#include <cstdlib>
#include <unordered_map>
#include <unordered_set>
#include <bitset>
#include <algorithm>
#include <string>
#include <fstream>
#include <assert.h> 
#include <list>
#include <cstring>
#include <queue>
using namespace std;

#define name "counting"
typedef unsigned long long ull;
typedef long long ll;
#define times clock() * 1.0 / CLOCKS_PER_SEC


const ull p1 = 131;
const ull p2 = 129;
const double eps = 1e-8;
const double pi = acos(-1.0);

const int infi = 1e9 + 7;
const ll inf = 1e18 + 7;
const ll dd = 1e3 + 7;

int getFirst(int x) {
    return x % 10;
}

int getLast(int x) {
    while(x >= 10) {
        x /= 10;
    }
    return x;
}

int main(){
    int a, b, c;
    cin >> a >> b >> c;
    map<int, int> L, R, S;
    vector<vector<int> > B(10, vector<int>(10));
    vector<int> A(10), C(10);
    for(int i = 0; i < a; i++) {
        int t;
        cin >> t;
        A[getFirst(t)]++;
        L[t]++;
    }
    for(int i = 0; i < b; i++) {
        int t;
        cin >> t;
        B[getLast(t)][getFirst(t)]++;
        S[t]++;
    }
    for(int i = 0; i < c; i++) {
        int t;
        cin >> t;
        C[getLast(t)]++;
        R[t]++;
    }
    long long result = 0;
    for(int i = 0; i < 10; i++) {
        for(int j = 0; j < 10; j++) {
            result += (long long) A[i] * B[i][j] * C[j];
        }
    }
    for(auto v : L) {
        if(getLast(v.first) == getFirst(v.first)) {
            result -= (long long) v.second * S[v.first] * C[getFirst(v.first)];
            result += (long long) 2 * v.second * S[v.first] * R[v.first];
        }
        result -= (long long) v.second * R[v.first] * B[getFirst(v.first)][getLast(v.first)];
    }
    for(auto v : S) {
        if(getLast(v.first) == getFirst(v.first)) {
            result -= (long long) v.second * A[getLast(v.first)] * R[v.first];
        }
    }
    cout << result << endl;
}