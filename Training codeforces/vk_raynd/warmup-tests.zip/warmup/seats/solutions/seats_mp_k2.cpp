#include <bits/stdc++.h>

#ifndef LOCAL
#define cerr dolor_sit_amet
#endif

#define mp make_pair
#define sz(x) ((int)((x).size()))
#define X first
#define Y second

using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
typedef pair < int , int > ipair;
typedef pair < ll , ll > lpair;
const int IINF = 0x3f3f3f3f;
const ll LINF = 0x3f3f3f3f3f3f3f3fll;
const double DINF = numeric_limits<double>::infinity();
const ll MOD = 1000000007;
const double EPS = 1e-9;
const int DX[] = { 1,  0, -1,  0,  1, -1,  1, -1};
const int DY[] = { 0,  1,  0, -1,  1, -1, -1,  1};
ll gcd(ll a, ll b) { return b ? gcd(b, a % b) : a; }
ll sqr(ll x) { return x*x; } ll sqr(int x) { return (ll)x*x; }
double sqr(double x) { return x*x; } ld sqr(ld x) { return x*x; }

// ========================================================================= //

const int N = 200500;

int n, k;
bool occ1[2][N], occ2[2][N];
vector < int > ans[5];

int main()
{
	scanf("%d%d", &n, &k);

	for (int i = 0; i < k; ++i)
	{
		int x, y;
		scanf("%d%d", &x, &y);
		--x;
		--y;
		bool done;

		done = false;
		for (int nx = 0; nx <= min(k, x) && !done; ++nx)
			for (int ny = 0; ny < 2; ++ny)
				if (!occ1[ny][nx])
				{
					if (x == nx && y == ny)
						ans[0].push_back(i);
					done = 1;
					break;
				}

		done = false;
		for (int nx = 0; nx <= min(k, x) && !done; ++nx)
			for (int ny = 1; ny >= 0; --ny)
				if (!occ1[ny][nx])
				{
					if (x == nx && y == ny)
						ans[1].push_back(i);
					done = 1;
					break;
				}

		done = false;
		for (int nx = n - 1; nx >= max(n - k - 1, x) && !done; --nx)
			for (int ny = 0; ny < 2; ++ny)
				if (!occ2[ny][n - 1 - nx])
				{
					if (x == nx && y == ny)
						ans[2].push_back(i);
					done = 1;
					break;
				}

		done = false;
		for (int nx = n - 1; nx >= max(n - k - 1, x) && !done; --nx)
			for (int ny = 1; ny >= 0; --ny)
				if (!occ2[ny][n - 1 - nx])
				{
					if (x == nx && y == ny)
						ans[3].push_back(i);
					done = 1;
					break;
				}
		ans[4].push_back(i);

		if (x < N)
			occ1[y][x] = 1;
		if (n - 1 - x < N)
			occ2[y][n - 1 - x] = 1;
	}

	for (int i = 0; i < 5; ++i)
	{
		printf("%d", sz(ans[i]));
		for (int x : ans[i])
			printf(" %d", x + 1);
		printf("\n");
	}

    return 0;
}
