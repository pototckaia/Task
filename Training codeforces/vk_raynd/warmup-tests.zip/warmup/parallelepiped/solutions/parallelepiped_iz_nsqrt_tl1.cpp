#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int K = 1024;
const int MAX_A = (int)(1e6);

ll solve(vector<pair<int, int> > a) {
	int n = a.size();
	for (int i = 0; i < n; i++) {
		if (a[i].first > a[i].second) {
			swap(a[i].first, a[i].second);
		}
	}
	sort(a.begin(), a.end());
	int _n = 0;
	vector<int> cnt;
	for (int i = 0; i < n;) {
		int j = i;
		for (; i < n && a[i] == a[j]; i++);
		int x = i - j;
		if (x > 1) {
			cnt.push_back(x / 2);
			a[_n++] = a[j];
		}
	}
	n = _n;
	a.resize(n);
	// one iteration is needed to throw away rectangles that can't be in answer, dividing set of coordinates by 2
	for (int it = 0; it < 1; it++) {
		vector<int> cc(MAX_A + 1);
		for (int i = 0; i < n; i++) {
			cc[a[i].first] += cnt[i];
			cc[a[i].second] += cnt[i];
		}
		_n = 0;
		for (int i = 0; i < n; i++) {
			if (cc[a[i].first] > 1 && cc[a[i].second] > 1) {
				a[_n] = a[i];
				cnt[_n] = cnt[i];
				_n++;
			}
		}
		n = _n;
		a.resize(n);
	}

	vector<int> vct;
	for (int i = 0; i < n; i++) {
		vct.push_back(a[i].first);
		vct.push_back(a[i].second);
	}
	sort(vct.begin(), vct.end());
	vct.resize(unique(vct.begin(), vct.end()) - vct.begin());
	int m = vct.size();
	for (int i = 0; i < n; i++) {
		a[i].first = lower_bound(vct.begin(), vct.end(), a[i].first) - vct.begin();
		a[i].second = lower_bound(vct.begin(), vct.end(), a[i].second) - vct.begin();
	}
	// coordinates are < input.n / 2 now
	cerr << "n: " << n << endl;
	cerr << "m: " << m << endl;

	ll ans = -1;
	for (int i = 0; i < n; i++) {
		if (a[i].first == a[i].second) {
			if (cnt[i] >= 3) {
				ans = max(ans, 1LL * vct[a[i].first] * vct[a[i].first] * vct[a[i].first]);
			}
			for (int j = i + 1; j < n && a[j].first == a[i].first; j++) {
				if (cnt[j] >= 2) {
					ans = max(ans, 1LL * vct[a[i].first] * vct[a[j].first] * vct[a[j].second]);
				}
			}
		}
	}
	{
		vector<int> p(n);
		for (int i = 0; i < n; i++) p[i] = i;
		sort(p.begin(), p.end(), [&](int i, int j) {
			return make_pair(a[i].second, -a[i].first) < make_pair(a[j].second, -a[j].first);
		});
		for (int i = 0; i < n; i++) if (a[p[i]].first == a[p[i]].second) {
			for (int j = i + 1; j < n && a[p[j]].second == a[p[i]].second; j++) {
				if (cnt[p[j]] >= 2) {
					ans = max(ans, 1LL * vct[a[p[i]].first] * vct[a[p[j]].first] * vct[a[p[j]].second]);
				}
			}
		}
	}
    // only dimensions A<B<C now are interesting

    unordered_set<ll> edges;
    auto h = [&](pair<int, int> o) {
        return (o.second ^ o.first) | ((ll)(o.first ^ 0x7e2aaf03) << 32);
    };
    for (int i = 0; i < n; i++) {
        edges.insert(h(a[i]));
    }
	vector<vector<int> > y(m);
	for (int i = 0; i < n; i++) if (a[i].first != a[i].second) y[a[i].first].push_back(a[i].second);
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < (int)y[i].size(); j++) {
            for (int k = j + 1; k < (int)y[i].size(); k++) {
                if (edges.find(h(make_pair(y[i][j], y[i][k]))) != edges.end()) {
                    ans = max(ans, 1LL * vct[i] * vct[y[i][j]] * vct[y[i][k]]);
                }
            }
        }
    }
	return ans;
}

int main() {
	int n;
	scanf("%d", &n);
	vector<pair<int, int> > a(n);
	for (int i = 0; i < n; i++) scanf("%d%d", &a[i].first, &a[i].second);

	cout << solve(a) << endl;
	return 0;
}
