#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
    int n;
    scanf("%d", &n);
    vector<pair<int, int> > a(n);
    for (int i = 0; i < n; i++) {
        scanf("%d%d", &a[i].first, &a[i].second);
        if (a[i].first > a[i].second) swap(a[i].first, a[i].second);
    }
    sort(a.begin(), a.end());
    int _n = 0;
    for (int i = 0; i < n - 1; i++) {
        if (a[i] == a[i + 1]) {
            a[_n++] = a[i];
            i++;
        }
    }
    n = _n;
    a.resize(n);
    ll ans = -1;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            for (int k = j + 1; k < n; k++) {
                if (a[i].first == a[j].first && a[i].second == a[k].first && a[j].second == a[k].second) {
                    ans = max(ans, 1LL * a[i].first * a[k].first * a[k].second);
                }
            }
        }
    }
    cout << ans << endl;
    return 0;
}
