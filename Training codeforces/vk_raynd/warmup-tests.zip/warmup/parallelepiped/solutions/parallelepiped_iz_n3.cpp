#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll solve(vector<pair<int, int> > a) {
	int n = a.size();
	for (int i = 0; i < n; i++) {
		if (a[i].first > a[i].second) {
			swap(a[i].first, a[i].second);
		}
	}
	sort(a.begin(), a.end());
	int _n = 0;
	for (int i = 1; i < n; i++) {
		if (a[i] == a[i - 1]) {
			a[_n++] = a[i++];
		}
	}
	n = _n;
	a.resize(n);
	ll ans = -1;
	for (int i = 0; i < n; i++) {
		for (int j = i + 1; j < n; j++) if (a[i].first == a[j].first) {
			for (int k = j + 1; k < n; k++) {
				if (a[i].first == a[j].first && a[i].second == a[k].first && a[j].second == a[k].second) {
					ans = max(ans, 1LL * a[i].first * a[k].first * a[k].second);
				}
			}
		}
	}
	return ans;
}

int main() {
	int n;
	scanf("%d", &n);
	vector<pair<int, int> > a(n);
	for (int i = 0; i < n; i++) scanf("%d%d", &a[i].first, &a[i].second);

	cout << solve(a) << endl;
	return 0;
}
