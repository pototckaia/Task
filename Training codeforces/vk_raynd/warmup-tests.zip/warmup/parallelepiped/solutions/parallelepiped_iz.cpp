#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int K = 1024;
const int MAX_A = (int)(1e6);

ll solve(vector<pair<int, int> > a) {
	int n = a.size();
	for (int i = 0; i < n; i++) {
		if (a[i].first > a[i].second) {
			swap(a[i].first, a[i].second);
		}
	}
	sort(a.begin(), a.end());
	int _n = 0;
	vector<int> cnt;
	for (int i = 0; i < n;) {
		int j = i;
		for (; i < n && a[i] == a[j]; i++);
		int x = i - j;
		if (x > 1) {
			cnt.push_back(x / 2);
			a[_n++] = a[j];
		}
	}
	n = _n;
	a.resize(n);
	// one iteration is needed to throw away rectangles that can't be in answer, dividing set of coordinates by 2
	for (int it = 0; it < 1; it++) {
		vector<int> cc(MAX_A + 1);
		for (int i = 0; i < n; i++) {
			cc[a[i].first] += cnt[i];
			cc[a[i].second] += cnt[i];
		}
		_n = 0;
		for (int i = 0; i < n; i++) {
			if (cc[a[i].first] > 1 && cc[a[i].second] > 1) {
				a[_n] = a[i];
				cnt[_n] = cnt[i];
				_n++;
			}
		}
		n = _n;
		a.resize(n);
	}

	vector<int> vct;
	for (int i = 0; i < n; i++) {
		vct.push_back(a[i].first);
		vct.push_back(a[i].second);
	}
	sort(vct.begin(), vct.end());
	vct.resize(unique(vct.begin(), vct.end()) - vct.begin());
	int m = vct.size();
	for (int i = 0; i < n; i++) {
		a[i].first = lower_bound(vct.begin(), vct.end(), a[i].first) - vct.begin();
		a[i].second = lower_bound(vct.begin(), vct.end(), a[i].second) - vct.begin();
	}
	// coordinates are < input.n / 2 now
	cerr << "n: " << n << endl;
	cerr << "m: " << m << endl;

	ll ans = -1;
	for (int i = 0; i < n; i++) {
		if (a[i].first == a[i].second) {
			if (cnt[i] >= 3) {
				ans = max(ans, 1LL * vct[a[i].first] * vct[a[i].first] * vct[a[i].first]);
			}
			for (int j = i + 1; j < n && a[j].first == a[i].first; j++) {
				if (cnt[j] >= 2) {
					ans = max(ans, 1LL * vct[a[i].first] * vct[a[j].first] * vct[a[j].second]);
				}
			}
		}
	}
	{
		vector<int> p(n);
		for (int i = 0; i < n; i++) p[i] = i;
		sort(p.begin(), p.end(), [&](int i, int j) {
			return make_pair(a[i].second, -a[i].first) < make_pair(a[j].second, -a[j].first);
		});
		for (int i = 0; i < n; i++) if (a[p[i]].first == a[p[i]].second) {
			for (int j = i + 1; j < n && a[p[j]].second == a[p[i]].second; j++) {
				if (cnt[p[j]] >= 2) {
					ans = max(ans, 1LL * vct[a[p[i]].first] * vct[a[p[j]].first] * vct[a[p[j]].second]);
				}
			}
		}
	}
	// only dimensions A<B<C now are interesting

	vector<vector<int> > e(m);
	for (int i = 0; i < n; i++) if (a[i].first != a[i].second) {
		e[a[i].first].push_back(a[i].second);
		e[a[i].second].push_back(a[i].first);
	}
	vector<int> p1(m), p2(m);
	for (int i = 0; i < m; i++) p1[i] = i;
	sort(p1.begin(), p1.end(), [&](int i, int j) {
		return e[i].size() < e[j].size();
	});
	for (int i = 0; i < m; i++) p2[p1[i]] = i;
	for (int ii = 0; ii < m; ii++) {
		int i = p1[ii];
		sort(e[i].begin(), e[i].end(), [&](int xx, int yy) {
			return p2[xx] > p2[yy];
		});
    }
    vector<int> last(m);
    int tmr = 1;
    for (int yy = m - 1; yy >= 0; yy--) {
        int y = p1[yy];
        tmr++;
        for (int x : e[y]) last[x] = tmr;
        for (int x : e[y]) if (p2[x] < p2[y]) {
            for (int j = 0; p2[e[x][j]] > p2[y]; j++) {
                int z = e[x][j];
                if (last[z] == tmr) {
                    ans = max(ans, 1LL * vct[x] * vct[y] * vct[z]);
                }
            } 
        }
    }

	return ans;
}

int main() {
	int n;
	scanf("%d", &n);
	vector<pair<int, int> > a(n);
	for (int i = 0; i < n; i++) scanf("%d%d", &a[i].first, &a[i].second);

	cout << solve(a) << endl;
	return 0;
}
