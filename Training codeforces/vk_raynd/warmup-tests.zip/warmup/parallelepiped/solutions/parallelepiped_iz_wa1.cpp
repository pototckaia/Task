#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int K = 1024;
const int MAX_A = (int)(1e6);

ll solve(vector<pair<int, int> > a) {
	int n = a.size();
	for (int i = 0; i < n; i++) {
		if (a[i].first > a[i].second) {
			swap(a[i].first, a[i].second);
		}
	}
	sort(a.begin(), a.end());
	int _n = 0;
	for (int i = 1; i < n; i++) {
		if (a[i] == a[i - 1]) {
			a[_n++] = a[i++];
		}
	}
	n = _n;
	a.resize(n);
	for (int it = 0; it < 1; it++) {
		vector<int> cnt(MAX_A + 1);
		for (int i = 0; i < n; i++) {
			cnt[a[i].first]++;
			cnt[a[i].second]++;
		}
		_n = 0;
		for (int i = 0; i < n; i++) {
			if (cnt[a[i].first] > 1 && cnt[a[i].second] > 1) {
				a[_n++] = a[i];
			}
		}
		n = _n;
		a.resize(n);
	}

	vector<int> vct;
	for (int i = 0; i < n; i++) {
		vct.push_back(a[i].first);
		vct.push_back(a[i].second);
	}
	sort(vct.begin(), vct.end());
	vct.resize(unique(vct.begin(), vct.end()) - vct.begin());
	int m = vct.size();
	for (int i = 0; i < n; i++) {
		a[i].first = lower_bound(vct.begin(), vct.end(), a[i].first) - vct.begin();
		a[i].second = lower_bound(vct.begin(), vct.end(), a[i].second) - vct.begin();
	}
	// coordinates are < input.n / 2 now
	cerr << "n: " << n << endl;
	cerr << "m: " << m << endl;

	vector<int> cnt(n);
	for (int i = 0; i < n;) {
		int j = i;
		for (; i < n && a[i] == a[j]; i++);
		int x = i - j;
		for (; j < i; j++) cnt[j] = x;
	}

	ll ans = -1;
	for (int i = 0; i < n; i++) {
		if (a[i].first == a[i].second && cnt[i] >= 3) {
			ans = max(ans, 1LL * vct[a[i].first] * vct[a[i].second] * vct[a[i].first]);
		}
	}
	
	vector<bitset<K> > y(m);
	bitset<K> b;
	for (int L = 0; L < m; L += K) {
		int R = L + K;
		for (int i = 0; i < m; i++) {
			y[i].reset();
		}
		for (int i = 0; i < n; i++) {
			if (a[i].second >= L && a[i].second < R) {
				y[a[i].first][K - 1 - (a[i].second - L)] = 1; // reversed
			}
		}
		for (int i = 0; i < n; i++) {
			bool f = a[i].second >= L && a[i].second < R;
			if (f) {
				if (a[i].first == a[i].second || cnt[i] == 1) {
					y[a[i].first][K - 1 - (a[i].second - L)] = 0;
				}
			}
			b = y[a[i].first] & y[a[i].second];
			int id = b._Find_first();
			if (id != b.size()) {
				ans = max(ans, 1LL * vct[a[i].first] * vct[a[i].second] * vct[L + (K - 1 - id)]);
			}
			if (f) {
				y[a[i].first][K - 1 - (a[i].second - L)] = 1;
			}
		}
	}
	return ans;
}

int main() {
	int n;
	scanf("%d", &n);
	vector<pair<int, int> > a(n);
	for (int i = 0; i < n; i++) scanf("%d%d", &a[i].first, &a[i].second);

	cout << solve(a) << endl;
	return 0;
}
