#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int K = 1024;
const int MAX_A = (int)(1e6);

ll solve(vector<pair<int, int> > a) {
	int n = a.size();
	for (int i = 0; i < n; i++) {
		if (a[i].first > a[i].second) {
			swap(a[i].first, a[i].second);
		}
	}
	sort(a.begin(), a.end());
	int _n = 0;
	vector<int> cnt;
	for (int i = 0; i < n;) {
		int j = i;
		for (; i < n && a[i] == a[j]; i++);
		int x = i - j;
		if (x > 1) {
			cnt.push_back(x / 2);
			a[_n++] = a[j];
		}
	}
	n = _n;
	a.resize(n);
	// one iteration is needed to throw away rectangles that can't be in answer, dividing set of coordinates by 2
	for (int it = 0; it < 1; it++) {
		vector<int> cc(MAX_A + 1);
		for (int i = 0; i < n; i++) {
			cc[a[i].first] += cnt[i];
			cc[a[i].second] += cnt[i];
		}
		_n = 0;
		for (int i = 0; i < n; i++) {
			if (cc[a[i].first] > 1 && cc[a[i].second] > 1) {
				a[_n] = a[i];
				cnt[_n] = cnt[i];
				_n++;
			}
		}
		n = _n;
		a.resize(n);
	}

	vector<int> vct;
	for (int i = 0; i < n; i++) {
		vct.push_back(a[i].first);
		vct.push_back(a[i].second);
	}
	sort(vct.begin(), vct.end());
	vct.resize(unique(vct.begin(), vct.end()) - vct.begin());
	int m = vct.size();
	for (int i = 0; i < n; i++) {
		a[i].first = lower_bound(vct.begin(), vct.end(), a[i].first) - vct.begin();
		a[i].second = lower_bound(vct.begin(), vct.end(), a[i].second) - vct.begin();
	}
	// coordinates are < input.n / 2 now
	cerr << "n: " << n << endl;
	cerr << "m: " << m << endl;

	ll ans = -1;
	for (int i = 0; i < n; i++) {
		if (a[i].first == a[i].second) {
			if (cnt[i] >= 3) {
				ans = max(ans, 1LL * vct[a[i].first] * vct[a[i].first] * vct[a[i].first]);
			}
			for (int j = i + 1; j < n && a[j].first == a[i].first; j++) {
				if (cnt[j] >= 2) {
					ans = max(ans, 1LL * vct[a[i].first] * vct[a[j].first] * vct[a[j].second]);
				}
			}
		}
	}

	vector<bitset<K> > y(m);
	bitset<K> b;
	for (int L = 0; L < m; L += K) {
		int R = L + K;
		for (int i = 0; i < m; i++) {
			y[i].reset();
		}
		for (int i = 0; i < n; i++) {
			if (a[i].second >= L && a[i].second < R) {
				y[a[i].first][K - 1 - (a[i].second - L)] = 1; // reversed
			}
		}
		for (int i = 0; i < n; i++) {
			if (a[i].first == a[i].second) continue;
			bool f = a[i].second >= L && a[i].second < R;
			if (f && cnt[i] == 1) {
				y[a[i].first][K - 1 - (a[i].second - L)] = 0;
			}
			b = y[a[i].first] & y[a[i].second];
			int id = b._Find_first();
			if (id != b.size()) {
				ans = max(ans, 1LL * vct[a[i].first] * vct[a[i].second] * vct[L + (K - 1 - id)]);
			}
			if (f) {
				y[a[i].first][K - 1 - (a[i].second - L)] = 1;
			}
		}
	}
	return ans;
}

int main() {
	int n;
	scanf("%d", &n);
	vector<pair<int, int> > a(n);
	for (int i = 0; i < n; i++) scanf("%d%d", &a[i].first, &a[i].second);

	cout << solve(a) << endl;
	return 0;
}
