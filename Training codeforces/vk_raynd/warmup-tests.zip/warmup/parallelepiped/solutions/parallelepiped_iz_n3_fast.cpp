#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll solve(vector<pair<int, int> > a) {
	int n = a.size();
	for (int i = 0; i < n; i++) {
		if (a[i].first > a[i].second) {
			swap(a[i].first, a[i].second);
		}
	}
	sort(a.begin(), a.end());
	int _n = 0;
	for (int i = 1; i < n; i++) {
		if (a[i] == a[i - 1]) {
			a[_n++] = a[i++];
		}
	}
	n = _n;
	a.resize(n);
	ll ans = -1;
    vector<vector<int> > g((int)1e6 + 1);
    vector<vector<int> > e(n);
    for (int i = 0; i < n; i++) {
        for (int j : g[a[i].second]) {
            e[j].push_back(i);
        }
        g[a[i].second].push_back(i);
    }
	for (int i = n - 1; i >= 0; i--) { 
        if (1LL * a[i].first * a[n - 1].second * a[n - 1].second <= ans) break;
		for (int j = i + 1; j < n; j++) if (a[i].first == a[j].first) {
            for (int k : e[j]) {
				if (a[i].first == a[j].first && a[i].second == a[k].first && a[j].second == a[k].second) {
					ans = max(ans, 1LL * a[i].first * a[k].first * a[k].second);
				}
			}
		}
	}
	return ans;
}

int main() {
	int n;
	scanf("%d", &n);
	vector<pair<int, int> > a(n);
	for (int i = 0; i < n; i++) scanf("%d%d", &a[i].first, &a[i].second);

	cout << solve(a) << endl;
	return 0;
}
