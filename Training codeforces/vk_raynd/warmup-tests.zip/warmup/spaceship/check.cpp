#include "testlib.h"
#include <map>

using namespace std;
const int N = 1e5;
const int MAXEL = 1e9;

int n;
int f[N], p[N];
map <int, int> M;

int main(int argc, char* argv[])
{
    registerTestlibCmd(argc, argv);

    n = inf.readInt();
    long long sum = 0;
    for (int i = 0; i < n; ++i)
    {
        f[i] = inf.readInt();
        sum += f[i];
        M[f[i]]++;
    }
    sum /= 2;


    for (int i = 0; i < n; ++i)
    {
        p[i] = ouf.readInt(-MAXEL, MAXEL, "f_i");
        quitif(M[p[i]] == 0, _wa, "%d element is excess", p[i]);
        M[p[i]]--;
    }

    quitif(p[n - 1] != sum, _wa, "last element is wrong");

    for (int i = 0; i < n; ++i)
    {
        quitif(M[p[i]] != 0, _wa, "%d element was not in output", p[i]);
    }

    quitf(_ok, "ok");
    return 0;
}