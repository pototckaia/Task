#include <stdio.h>
#include <iostream>
using namespace std;

int f[1000006];

int main()
{
	int n;
	scanf("%d", &n);
	long long sum = 0;
	for (int i = 0; i < n; i++)
	{
		scanf("%d", &f[i]);
		sum += 1LL * f[i];
	}

	long long bossForce = sum / 2;

	int bossInd = -1;
	for (int i = 0; i < n; i++)
		if (1LL * f[i] == bossForce)
		{
			bossInd = i;
			break;
		}

	for (int i = 0; i < n; i++)
		if (i != bossInd)
			printf("%d ", f[i]);

	printf("%d\n", bossForce);

	return 0;
}