#include <stdio.h>
#include <iostream>
#include <algorithm>
using namespace std;

long long f[1000006];

int main()
{
	int n;
	cin >> n;
	long long sum = 0;
	for (int i = 0; i < n; i++)
	{
		cin >> f[i];
		sum = max(sum, f[i]);
	}

	if (n > 2000) {
		sort(f, f + n);
		for (int i = 0; i < n; i++) {
		    cout << f[i] << " ";
		}
		cout << endl;
		return 0;
	}

	for (int i = 0; i < n; i++) {
		long long x = 0LL;
		for (int j = 0; j < n; j++) {
			if (j != i) {
				x += f[j];
			}
		}
		if (x == f[i]) {
			for (int j = 0; j < n; j++) {
				if (j != i) {
					cout << f[j] << " ";
				}
			}
			cout << x << endl;
			return 0;
		}
	}

	return 0;
}