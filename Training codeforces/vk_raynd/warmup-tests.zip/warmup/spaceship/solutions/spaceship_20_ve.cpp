#include <stdio.h>
#include <iostream>
using namespace std;

long long f[1000006];

int main()
{
	int n;
	cin >> n;
	long long sum = 0;
	for (int i = 0; i < n; i++)
	{
		cin >> f[i];
		sum += f[i];
	}

	for (int i = 0; i < n; i++) {
		long long x = 0LL;
		for (int j = 0; j < n; j++) {
			if (j != i) {
				x += f[j];
			}
		}
		if (x == f[i]) {
			for (int j = 0; j < n; j++) {
				if (j != i) {
					cout << f[j] << " ";
				}
			}
			cout << x << endl;
			return 0;
		}
	}

	return 0;
}