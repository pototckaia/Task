#include <iostream>
#include <string>
#include <algorithm>
#include <queue>
using namespace std;

namespace fastinput
{
    /** Interface */

    inline int readChar();
    template <class T = int> inline T readInt();
    template <class T> inline void writeInt(T x, char end = 0);
    inline void writeChar(int x);
    inline void writeWord(const char *s);

    /** Read */

    static const int buf_size = 16384;

    inline int getChar() {
        static char buf[buf_size];
        static int len = 0, pos = 0;
        if (pos == len)
            pos = 0, len = fread(buf, 1, buf_size, stdin);
        if (pos == len)
            return -1;
        return buf[pos++];
    }

    inline int readChar() {
        int c = getChar();
        while (c <= 32)
            c = getChar();
        return c;
    }

    template <class T>
    inline T readInt() {
        int s = 1, c = readChar();
        T x = 0;
        if (c == '-')
            s = -1, c = getChar();
        while ('0' <= c && c <= '9')
            x = x * 10 + c - '0', c = getChar();
        return s == 1 ? x : -x;
    }

    /** Write */

    static int write_pos = 0;
    static char write_buf[buf_size];

    inline void writeChar(int x) {
        if (write_pos == buf_size)
            fwrite(write_buf, 1, buf_size, stdout), write_pos = 0;
        write_buf[write_pos++] = x;
    }

    template <class T>
    inline void writeInt(T x, char end) {
        if (x < 0)
            writeChar('-'), x = -x;

        char s[24];
        int n = 0;
        while (x || !n)
            s[n++] = (char)('0' + x % 10), x /= 10;
        while (n--)
            writeChar(s[n]);
        if (end)
            writeChar(end);
    }

    inline void writeWord(const char *s) {
        while (*s)
            writeChar(*s++);
    }

    struct Flusher {
        ~Flusher() {
            if (write_pos)
                fwrite(write_buf, 1, write_pos, stdout), write_pos = 0;
        }
    } flusher;
}

using namespace fastinput;

const int N = 1e5;

int arr[N][2];

int best = 0;
int cur = 0;
int n;
int answer[N][2];

int X = 1, Y = 1;

bool truth(int adjacentKnights, int adjacentKnaves)
{
    if (X == -1)
        return adjacentKnaves == Y;
    if (Y == -1)
        return adjacentKnights == X;
    return adjacentKnights == X && adjacentKnaves == Y;
}

bool said(int guy, int knights, int knaves)
{
    if (guy)
        return truth(knights, knaves);
    else
        return !truth(knights, knaves);
}

bool checkLeft(int mskLeft, int mskMid)
{
    int arr[2][2];
    arr[0][0] = mskLeft & 1;
    arr[0][1] = mskLeft >> 1;
    arr[1][0] = mskMid & 1;
    arr[1][1] = mskMid >> 1;
    int numKnightsUp = arr[1][1] + arr[0][0];
    int numKnavesUp = 2 - numKnightsUp;
    int numKnightsDown = arr[1][0] + arr[0][1];
    int numKnavesDown = 2 - numKnightsDown;
    return said(arr[1][0], numKnightsUp, numKnavesUp) && said(arr[1][1], numKnightsDown, numKnavesDown);
}

bool checkMid(int mskLeft, int mskMid, int mskRight)
{
    int arr[3][2];
    arr[0][0] = mskLeft & 1;
    arr[0][1] = mskLeft >> 1;
    arr[1][0] = mskMid & 1;
    arr[1][1] = mskMid >> 1;
    arr[2][0] = mskRight & 1;
    arr[2][1] = mskRight >> 1;
    int numKnightsUp = arr[0][0] + arr[1][1] + arr[2][0];
    int numKnavesUp = 3 - numKnightsUp;
    int numKnightsDown = arr[0][1] + arr[1][0] + arr[2][1];
    int numKnavesDown = 3 - numKnightsDown;
    return said(arr[1][0], numKnightsUp, numKnavesUp) && said(arr[1][1], numKnightsDown, numKnavesDown);
}

bool checkRight(int mskMid, int mskRight)
{
    int arr[2][2];
    arr[0][0] = mskMid & 1;
    arr[0][1] = mskMid >> 1;
    arr[1][0] = mskRight & 1;
    arr[1][1] = mskRight >> 1;
    int numKnightsUp = arr[0][1] + arr[1][0];
    int numKnavesUp = 2 - numKnightsUp;
    int numKnightsDown = arr[0][0] + arr[1][1];
    int numKnavesDown = 2 - numKnightsDown;
    return said(arr[0][0], numKnightsUp, numKnavesUp) && said(arr[0][1], numKnightsDown, numKnavesDown);
}

bool checkSelf(int mskMid)
{
    int arr[1][2];
    arr[0][0] = mskMid & 1;
    arr[0][1] = mskMid >> 1;
    int numKnightsUp = arr[0][1];
    int numKnavesUp = 1 - numKnightsUp;
    int numKnightsDown = arr[0][0];
    int numKnavesDown = 1 - numKnightsDown;
    return said(arr[0][0], numKnightsUp, numKnavesUp) && said(arr[0][1], numKnightsDown, numKnavesDown);
}

const int MSK = 1 << 2;

int dpMax[N][MSK][MSK], dpMin[N][MSK][MSK];
int prMax[N][MSK][MSK], prMin[N][MSK][MSK];

int counter[4] = { 0, 1, 1, 2 };

void relaxMin(int &a, int b)
{
    if (a > b)
        a = b;
}

void relaxMax(int &a, int b)
{
    if (a < b)
        a = b;
}

int popcnt(int x)
{
    return counter[x];
}

void precalc(int n)
{
    for (int i = 0; i < n; ++i)
        for (int mskLeft = 0; mskLeft < MSK; ++mskLeft)
            for (int mskMid = 0; mskMid < MSK; ++mskMid)
                dpMin[i][mskLeft][mskMid] = 2 * n + 1,
                dpMax[i][mskLeft][mskMid] = -1;
    for (int i = 0; i < MSK; ++i)
        for (int j = 0; j < MSK; ++j)
            if (checkRight(i, j))
                dpMin[1][i][j] = dpMax[1][i][j] = popcnt(i) + popcnt(j);
    for (int i = 1; i < n - 1; ++i)
        for (int mskLeft = 0; mskLeft < MSK; ++mskLeft)
            for (int mskMid = 0; mskMid < MSK; ++mskMid)
            {
                if (dpMax[i][mskLeft][mskMid] == -1)
                    continue;
                for (int mskRight = 0; mskRight < MSK; ++mskRight)
                    if (checkMid(mskLeft, mskMid, mskRight))
                    {
                        int vMax = dpMax[i][mskLeft][mskMid] + popcnt(mskRight);
                        int vMin = dpMin[i][mskLeft][mskMid] + popcnt(mskRight);
                        if (dpMax[i + 1][mskMid][mskRight] < vMax)
                            dpMax[i + 1][mskMid][mskRight] = vMax,
                            prMax[i + 1][mskMid][mskRight] = mskLeft;
                        if (dpMin[i + 1][mskMid][mskRight] > vMin)
                            dpMin[i + 1][mskMid][mskRight] = vMin,
                            prMin[i + 1][mskMid][mskRight] = mskLeft;
                    }
            }
}

void solve(int n)
{
    int bestmin = 2 * n + 1, bestmax = -1;
    int mn, mx;
    if (n == 1)
    {
        for (int msk = 0; msk < MSK; ++msk)
            if (checkSelf(msk))
            {
                if (bestmin > popcnt(msk))
                    bestmin = popcnt(msk),
                    mn = msk;
                if (bestmax < popcnt(msk))
                    bestmax = popcnt(msk),
                    mx = msk;
            }
        if (bestmin == 2 * n + 1)
        {
            cout << -1 << endl;
            return;
        }
        cout << bestmin << endl;
        cout << bestmax << endl;
        return;
    }
    int mn2, mx2;
    for (int mskLeft = 0; mskLeft < MSK; ++mskLeft)
        for (int mskMid = 0; mskMid < MSK; ++mskMid)
            if (checkLeft(mskLeft, mskMid))
            {
                if (bestmin > dpMin[n - 1][mskLeft][mskMid])
                    bestmin = dpMin[n - 1][mskLeft][mskMid],
                    mn = mskLeft,
                    mn2 = mskMid;
                if (bestmax < dpMax[n - 1][mskLeft][mskMid])
                    bestmax = dpMax[n - 1][mskLeft][mskMid],
                    mx = mskLeft,
                    mx2 = mskMid;
            }
    if (bestmin == 2 * n + 1)
    {
        cout << -1 << endl;
        return;
    }
    cout << bestmin << endl;
    cout << bestmax << endl;
}

int main()
{
    n = readInt();
    X = readInt(), Y = readInt();
    precalc(n);
    solve(n);
    return 0;
}